import pathlib
import json
import os
import re
import asyncio

from telegram import (
    Update,
    MessageEntity,
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardRemove,
    CallbackQuery,
)
from telegram.constants import ParseMode
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
    CallbackQueryHandler,
)

# --- КОНФИГУРАЦИЯ ---
TOKEN = "7848203824:AAGVFRsilL9ibTboyE46Hx-gZJw1kIptAvI"
BASE_DIR = pathlib.Path(__file__).resolve().parent
MIN_FILE = BASE_DIR / "МИН_УЧАСТНИКОВ.json"
ARCHIVE_DIR = pathlib.Path("C:\\Софт\\1TGlinkV1.0\\АРХИВ")
TEMPLATES_DIR = pathlib.Path("C:\\Софт\\1TGlinkV1.0\\ШАБЛОНЫ")

FINAL_DEST_DIR = pathlib.Path("C:/Софт/2Onlinechat_checker V1.0")

# Создаем папки, если они не существуют
ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
FINAL_DEST_DIR.mkdir(parents=True, exist_ok=True)
TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)

# --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---

def load_min_members() -> dict:
    """Загружает минимальное количество участников из файла для публичных и приватных чатов."""
    if MIN_FILE.exists():
        try:
            with open(MIN_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return {
                    "public_min_members": data.get("public_min_members", 0),
                    "private_min_members": data.get("private_min_members", 0)
                }
        except (json.JSONDecodeError, IOError):
            pass
    return {"public_min_members": 0, "private_min_members": 0}

def save_min_members(public_value: int, private_value: int) -> None:
    """Сохраняет минимальное количество участников в файл для публичных и приватных чатов."""
    with open(MIN_FILE, "w", encoding="utf-8") as f:
        json.dump({
            "public_min_members": public_value,
            "private_min_members": private_value
        }, f, ensure_ascii=False, indent=2)

def parse_member_count(text: str) -> int:
    """Извлекает количество участников из строки (например, "-3.5k" -> 3500)."""
    text = text.replace('\xa0', ' ').replace('\u202f', ' ')
    if m := re.search(r"-?(\d+(?:[.,]\d+)?)k", text, re.I):
        try:
            return int(float(m.group(1).replace(",", ".")) * 1000)
        except ValueError:
            pass
    if m := re.search(r"-?(\d{1,7})", text):
        try:
            return int(m.group(1))
        except ValueError:
            pass
    return 0

def split_by_chat_type(links):
    """Разделяет ссылки на приватные и публичные."""
    private = [u for u in links if u.startswith("https://t.me/+")]
    public = [u for u in links if u.startswith("https://t.me/") and not u.startswith("https://t.me/+")]
    return private, public

def create_progress_bar(percentage: int, bar_length: int = 20) -> str:
    """Генерирует строку визуального прогресс-бара с эмодзи."""
    filled_blocks = int(bar_length * percentage / 100)
    empty_blocks = bar_length - filled_blocks
    return "█" * filled_blocks + "░" * empty_blocks + f" {percentage}%"

# --- КЛАВИАТУРЫ ---

def main_menu_keyboard():
    buttons = [
        [KeyboardButton("Ручной режим"), KeyboardButton("Авто режим")],
        [KeyboardButton("Архив чатов"), KeyboardButton("Шаблоны")]
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True, one_time_keyboard=True)

def manual_mode_keyboard():
    buttons = [
        [KeyboardButton("Установить тег"), KeyboardButton("Узнать тег")],
        [KeyboardButton("Установить лимит"), KeyboardButton("Узнать лимит")],
        [KeyboardButton("✅ Готово (Получить чаты)"), KeyboardButton("Назад")],
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)

def auto_mode_keyboard():
    buttons = [[KeyboardButton("Назад")]]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)

def archive_folder_inline_keyboard():
    """Создает Inline-клавиатуру ТОЛЬКО с названиями папок архива."""
    if not ARCHIVE_DIR.is_dir():
        return None

    folders = sorted([f.name for f in ARCHIVE_DIR.iterdir() if f.is_dir()])
    buttons = []
    for folder in folders:
        buttons.append([InlineKeyboardButton(folder, callback_data=f"archive_{folder}")])
    
    return InlineKeyboardMarkup(buttons)

def archive_menu_reply_keyboard():
    """Создает Reply-клавиатуру для меню архива с кнопками 'Сравнить ссылки' и 'Назад'."""
    buttons = [
        [KeyboardButton("Сравнить ссылки")],
        [KeyboardButton("Назад")]
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True, one_time_keyboard=True)

def templates_menu_keyboard():
    buttons = [
        [KeyboardButton("Редактор"), KeyboardButton("Просмотр")],
        [KeyboardButton("Назад")]
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True, one_time_keyboard=True)

def templates_editor_keyboard():
    buttons = [
        [KeyboardButton("Создать шаблон"), KeyboardButton("Редактировать шаблон")],
        [KeyboardButton("Удалить шаблон")],
        [KeyboardButton("Назад")]
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True, one_time_keyboard=True)

def template_edit_options_keyboard():
    buttons = [
        [InlineKeyboardButton("Редактировать текст", callback_data="edit_template_text")],
        [InlineKeyboardButton("Редактировать кнопки", callback_data="edit_template_buttons")],
        [InlineKeyboardButton("Назад", callback_data="back_to_template_editor")]
    ]
    return InlineKeyboardMarkup(buttons)

# --- НОВАЯ СИСТЕМА ШАБЛОНОВ (ВЗАМЕН СТАРОЙ) ---

def load_template_blocks(template_name: str):
    """Загружает JSON файл в виде словаря."""
    template_file = TEMPLATES_DIR / f"{template_name}.json"
    if not template_file.exists():
        return None
    try:
        with open(template_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        print(f"Ошибка при загрузке шаблона '{template_name}': {e}")
        return None

async def show_template_block(message, context, template_name: str, block_id: str):
    """Отправляет пользователю текст и кнопки выбранного блока."""
    template_blocks = load_template_blocks(template_name)
    if not template_blocks or str(block_id) not in template_blocks:
        await message.reply_text("Блок шаблона не найден.")
        return

    block_data = template_blocks[str(block_id)]
    text = block_data.get("text", "Текст не найден.")
    buttons_data = block_data.get("buttons", [])

    inline_buttons = []
    for btn in buttons_data:
        btn_list = []
        # Мы используем targetBlockId в качестве callback_data
        btn_list.append(InlineKeyboardButton(btn.get("text"), callback_data=f"block_{template_name}_{btn.get('targetBlockId')}"))
        if btn_list:
            inline_buttons.append(btn_list)
    
    reply_markup = InlineKeyboardMarkup(inline_buttons) if inline_buttons else None
    
    def escape_html(text):
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    formatted_text = f"<pre>{escape_html(text)}</pre>"
    
    await message.reply_text(
        formatted_text,
        reply_markup=reply_markup,
        parse_mode=ParseMode.HTML
    )

async def handle_template_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик нажатия на инлайн-кнопки шаблонов."""
    query = update.callback_query
    await query.answer()

    data = query.data
    
    if data.startswith("show_template_"):
        template_name = data.split("show_template_", 1)[1]
        # Предполагаем, что начальный блок всегда имеет id 0
        await show_template_block(query.message, context, template_name, 0)
    
    elif data.startswith("block_"):
        parts = data.split('_', 2)
        template_name = parts[1]
        block_id = parts[2]
        await show_template_block(query.message, context, template_name, block_id)

    elif data.startswith("edit_template_") or data.startswith("delete_template_") or data == "confirm_delete_template":
        # Заглушки для функционала, которого нет в новой системе
        await query.message.reply_text("Функция редактирования шаблонов в текущем формате не поддерживается.")
    elif data == "edit_template_text" or data == "edit_template_buttons" or data == "back_to_template_editor":
        await go_back_to_templates_menu(query, context)


# --- ОБРАБОТЧИКИ СОСТОЯНИЙ И КОМАНД ---

def clear_user_state(context: ContextTypes.DEFAULT_TYPE):
    """Очищает все флаги состояния пользователя и удаляет временные файлы, если они не были перемещены."""
    
    files_to_move = context.user_data.pop("files_to_move", [])
    for file_path_str in files_to_move:
        try:
            file_path = pathlib.Path(file_path_str)
            if file_path.exists():
                os.remove(file_path)
                print(f"DEBUG: Локально удален оставшийся файл: {file_path.name}")
        except Exception as e:
            print(f"DEBUG: Ошибка при локальном удалении оставшегося файла {file_path_str}: {e}")

    keys_to_clear = [
        "mode_selected", "awaiting_min_input", "awaiting_tag_input",
        "current_tag", "user_links", "awaiting_archive_selection",
        "public_min_members", "private_min_members",
        "awaiting_template_action", "current_template_name",
        "current_template_text", "current_template_buttons",
    ]
    for key in keys_to_clear:
        context.user_data.pop(key, None)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start. Сбрасывает состояние и показывает главное меню."""
    if isinstance(update, CallbackQuery):
        message_to_reply = update.message
    else:
        message_to_reply = update.message
        
    clear_user_state(context)
    await message_to_reply.reply_text(
        "Привет! Выберите режим работы бота:",
        reply_markup=main_menu_keyboard()
    )

async def go_back_to_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возвращает пользователя в главное меню, сбрасывая состояние."""
    clear_user_state(context)
    await update.message.reply_text("Возврат в главное меню...", reply_markup=ReplyKeyboardRemove())
    await start(update, context)

async def go_back_to_templates_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возвращает пользователя в меню шаблонов, сбрасывая временное состояние."""
    context.user_data.pop("awaiting_template_action", None)
    context.user_data.pop("current_template_name", None)
    context.user_data.pop("current_template_text", None)
    context.user_data.pop("current_template_buttons", None)
    await update.message.reply_text("Возврат в меню 'Шаблоны'...", reply_markup=templates_menu_keyboard())


async def done(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Завершает сбор ссылок, формирует, отправляет файлы и предлагает переместить только файл 'все.txt'."""
    current_tag = context.user_data.get("current_tag")
    if not current_tag:
        await update.message.reply_text("Ошибка: Сначала установите тег через кнопку 'Установить тег'.")
        return

    links = context.user_data.get("user_links", [])
    
    if not links:
        await update.message.reply_text("Ссылок нет. Пожалуйста, перешлите сообщения с чатами.")
        clear_user_state(context)
        return

    private_links, public_links = split_by_chat_type(links)
    all_unique_links = sorted(list(set(links)))
    context.user_data["files_to_move"] = []
    files_to_send_and_delete_locally = []

    files_sent = False

    for link_group, label in (
        (private_links, "приватных"),
        (public_links, "публичных"),
    ):
        if not link_group and label != "приватных":
            continue
        
        files_sent = True
        unique_links = sorted(list(set(link_group)))
        filename = f"{current_tag}_{len(unique_links)}_{label}.txt"
        
        try:
            with open(filename, "w", encoding="utf-8") as f:
                if unique_links:
                    f.write("\n".join(unique_links))
                else:
                    f.write("# В этой категории ссылок не найдено.")
            
            absolute_path = str(pathlib.Path(filename).resolve())
            
            if "приватных" in filename or "публичных" in filename:
                context.user_data["files_to_move"].append(absolute_path)
            else:
                files_to_send_and_delete_locally.append(absolute_path)

            with open(filename, "rb") as doc:
                await update.message.reply_document(document=doc)
            
        except Exception as e:
            await update.message.reply_text(f"Произошла ошибка при создании файла '{filename}': {e}")

    if all_unique_links:
        files_sent = True
        all_filename = f"{current_tag}_{len(all_unique_links)}_все.txt"
        try:
            with open(all_filename, "w", encoding="utf-8") as f:
                f.write("\n".join(all_unique_links))
            
            absolute_path_all = str(pathlib.Path(all_filename).resolve())
            files_to_send_and_delete_locally.append(absolute_path_all)

            with open(all_filename, "rb") as doc:
                await update.message.reply_document(document=doc)
        except Exception as e:
            await update.message.reply_text(f"Произошла ошибка при создании файла '{all_filename}': {e}")

    for file_path_str in files_to_send_and_delete_locally:
        try:
            file_path = pathlib.Path(file_path_str)
            if file_path.exists():
                os.remove(file_path)
                print(f"DEBUG: Локально удален файл: {file_path.name}")
        except Exception as e:
            print(f"DEBUG: Ошибка при локальном удалении файла {file_path_str}: {e}")

    if files_sent:
        keyboard = [[InlineKeyboardButton("отправить в папку", callback_data="move_to_folder")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            "Готово! Файлы с чатами отправлены.",
            reply_markup=reply_markup
        )
        context.user_data.pop("user_links", None) 
    else:
        await update.message.reply_text("Не найдено ссылок для формирования файлов.")
        clear_user_state(context)

async def move_files_to_final_folder(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Перемещает файлы в конечную папку по нажатию инлайн-кнопки (только файлы 'приватных.txt' и 'публичных.txt')."""
    query = update.callback_query
    await query.answer()

    files_to_move = context.user_data.get("files_to_move", [])
    
    if not files_to_move:
        await query.edit_message_text(text=f"{query.message.text}\n\n(Файлы уже перемещены или не найдены)")
        return
        
    try:
        moved_count = 0
        for file_path_str in files_to_move:
            source_path = pathlib.Path(file_path_str)
            if source_path.exists():
                dest_path = FINAL_DEST_DIR / source_path.name
                source_path.rename(dest_path)
                moved_count += 1
            else:
                print(f"DEBUG: Файл не найден для перемещения (возможно, уже удален): {source_path.name}")
        
        await query.edit_message_reply_markup(reply_markup=None)
        await context.bot.send_message(chat_id=update.effective_chat.id, text=f"Успешно перемещено {moved_count} файла(ов).")

    except Exception as e:
        await context.bot.send_message(chat_id=update.effective_chat.id, text=f"❌ Произошла ошибка при перемещении: {e}")
    finally:
        clear_user_state(context)


# --- ГЛАВНЫЙ ОБРАБОТЧИК СООБЩЕНИЙ (ДИСПЕТЧЕР) ---
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message_text = update.message.text
    
    if context.user_data.get("mode_selected") == "templates" and context.user_data.get("awaiting_template_action") == "editor_menu":
        if message_text == "Создать шаблон":
            await update.message.reply_text("Функция создания шаблонов в текущем формате не поддерживается.")
            return
        elif message_text == "Редактировать шаблон":
            await update.message.reply_text("Функция редактирования шаблонов в текущем формате не поддерживается.")
            return
        elif message_text == "Удалить шаблон":
            await update.message.reply_text("Функция удаления шаблонов в текущем формате не поддерживается.")
            return
        elif message_text == "Назад":
            await go_back_to_templates_menu(update, context)
            return

    # Existing logic
    if context.user_data.get("awaiting_min_input"):
        parts = message_text.split(':')
        if len(parts) == 2:
            try:
                public_val = int(parts[0].strip())
                private_val = int(parts[1].strip())
                if public_val < 0 or private_val < 0: raise ValueError
                
                context.user_data["public_min_members"] = public_val
                context.user_data["private_min_members"] = private_val
                save_min_members(public_val, private_val)
                await update.message.reply_text(
                    f"✅ Минимальный лимит установлен:\n"
                    f"Публичные: {public_val}\n"
                    f"Приватные: {private_val}",
                    reply_markup=manual_mode_keyboard()
                )
            except (ValueError, TypeError):
                await update.message.reply_text(
                    "❌ Ошибка: введите два целых числа, разделенных двоеточием (например, 500:100).",
                    reply_markup=manual_mode_keyboard()
                )
            finally:
                context.user_data.pop("awaiting_min_input", None)
        else:
            await update.message.reply_text(
                "❌ Ошибка: введите два числа, разделенных двоеточием (например, 500:100).",
                reply_markup=manual_mode_keyboard()
            )
        return

    if context.user_data.get("awaiting_tag_input"):
        if not re.fullmatch(r"[а-яА-ЯёЁa-zA-Z0-9]+", message_text):
            await update.message.reply_text("❌ Ошибка: тег должен содержать только буквы или цифры.", reply_markup=manual_mode_keyboard())
        else:
            tag = message_text.lower()
            context.user_data["current_tag"] = tag
            await update.message.reply_text(f"✅ Тег '{tag}' установлен.", reply_markup=manual_mode_keyboard())
        context.user_data.pop("awaiting_tag_input", None)
        return

    if context.user_data.get("mode_selected") == "archive":
        if message_text == "Сравнить ссылки":
            await compare_and_clean_archive_links(update, context)
            return

    if context.user_data.get("mode_selected") == "manual":
        await collect_links_from_message(update, context)
        return

# --- ЛОГИКА РЕЖИМОВ ---
async def handle_menu_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    choice = update.message.text
    clear_user_state(context)

    if choice == "Ручной режим":
        context.user_data["mode_selected"] = "manual"
        current_limits = load_min_members()
        context.user_data["public_min_members"] = current_limits["public_min_members"]
        context.user_data["private_min_members"] = current_limits["private_min_members"]

        await update.message.reply_text(
            "Вы в 'Ручном режиме'.\nПересылайте сообщения с чатами, используйте кнопки для настроек.",
            reply_markup=manual_mode_keyboard()
        )
    elif choice == "Авто режим":
        context.user_data["mode_selected"] = "auto"
        await update.message.reply_text(
            "Автоматический режим пока не реализован.",
            reply_markup=auto_mode_keyboard()
        )
    elif choice == "Архив чатов":
        context.user_data["mode_selected"] = "archive"
        archive_inline_kb = archive_folder_inline_keyboard()
        if archive_inline_kb and archive_inline_kb.inline_keyboard:
            await update.message.reply_text("Выберите папку архива:", reply_markup=archive_inline_kb)
        else:
            await update.message.reply_text("В архиве нет папок для выбора.")
        await update.message.reply_text("Дополнительные действия:", reply_markup=archive_menu_reply_keyboard())
    elif choice == "Шаблоны":
        context.user_data["mode_selected"] = "templates"
        await update.message.reply_text("Вы в меню 'Шаблоны'. Выберите действие:", reply_markup=templates_menu_keyboard())

# Обработчик кнопок меню шаблонов
async def handle_templates_menu_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    choice = update.message.text
    if choice == "Редактор":
        context.user_data["awaiting_template_action"] = "editor_menu"
        await update.message.reply_text("Вы в редакторе. Что хотите сделать?", reply_markup=templates_editor_keyboard())
    elif choice == "Просмотр":
        await view_templates(update, context)
    elif choice == "Назад":
        await go_back_to_main_menu(update, context)

async def handle_manual_mode_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    choice = update.message.text
    if choice == "Установить тег":
        context.user_data["awaiting_tag_input"] = True
        await update.message.reply_text("Какой тег хотите установить?")
    elif choice == "Узнать тег":
        current_tag = context.user_data.get("current_tag", "не установлен")
        await update.message.reply_text(f"Текущий тег: '{current_tag}'")
    elif choice == "Установить лимит":
        context.user_data["awaiting_min_input"] = True
        await update.message.reply_text("Введите минимальное количество участников для публичных и приватных чатов в формате ПУБЛИЧНЫЕ:ПРИВАТНЫЕ (например, 500:100):")
    elif choice == "Узнать лимит":
        current_limits = load_min_members()
        public_min = context.user_data.get("public_min_members", current_limits["public_min_members"])
        private_min = context.user_data.get("private_min_members", current_limits["private_min_members"])
        await update.message.reply_text(
            f"Текущий минимальный лимит:\n"
            f"Публичные чаты: {public_min}\n"
            f"Приватные чаты: {private_min}"
        )
    elif choice == "✅ Готово (Получить чаты)":
        await done(update, context)

# Функции для работы с шаблонами
async def view_templates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отображает список сохраненных шаблонов."""
    templates = sorted([f.stem for f in TEMPLATES_DIR.glob("*.json")])
    if not templates:
        await update.message.reply_text("Шаблонов пока нет.")
        return

    buttons = [[InlineKeyboardButton(t, callback_data=f"show_template_{t}")] for t in templates]
    await update.message.reply_text("Выберите шаблон для просмотра:", reply_markup=InlineKeyboardMarkup(buttons))


# --- ЛОГИКА АРХИВА ---
async def handle_archive_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data.startswith("archive_"):
        folder_name = query.data.split('_', 1)[1]
        await handle_archive_folder_selection(query, context, folder_name)

async def handle_archive_folder_selection(query: CallbackQuery, context, folder_name: str):
    found_folder = ARCHIVE_DIR / folder_name
    if not found_folder.is_dir():
        await query.message.chat.send_message("Папка не найдена.")
        return

    await query.message.edit_text(f"Отправляю файлы из архива '{found_folder.name}'...")
    files = list(found_folder.rglob('*.txt'))
    if not files:
        await query.message.chat.send_message("В выбранном архиве нет .txt файлов.")
    else:
        for file_path in files:
            try:
                await query.message.chat.send_document(document=open(file_path, "rb"))
            except Exception as e:
                await query.message.chat.send_message(f"Не удалось отправить '{file_path.name}': {e}")
        await query.message.chat.send_message("Все файлы из архива отправлены.")
    
    await query.message.chat.send_message("Возврат в главное меню...", reply_markup=ReplyKeyboardRemove())
    await start(query, context)

async def compare_and_clean_archive_links(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Сравнивает ссылки из всех файлов в архивах, удаляет дубликаты и отображает прогресс.
    Добавлено формирование подробного отчета об удаленных ссылках и файлах.
    """
    progress_message = await update.message.reply_text("Начинаю сравнение и очистку архивов... 0%")

    all_links_in_archive = []
    files_data = {}
    
    deleted_links_report = [] 
    files_removed_report = [] 

    files_to_process = []
    if ARCHIVE_DIR.is_dir():
        for root, _, files in os.walk(ARCHIVE_DIR):
            for file_name in files:
                if (file_name.lower().startswith("links") or 
                    file_name.lower().startswith("сбор") or
                    "приватных" in file_name.lower()
                   ) and file_name.lower().endswith(".txt"):
                    file_path = pathlib.Path(root) / file_name
                    files_to_process.append(file_path)

    files_to_process.sort(key=lambda f: f.stat().st_mtime)

    total_files = len(files_to_process)
    if total_files == 0:
        await progress_message.edit_text(
            "В архивах не найдено подходящих файлов для сравнения."
        )
        await update.message.reply_text(
            "Вы вернулись в главное меню. Выберите режим работы:",
            reply_markup=main_menu_keyboard()
        )
        clear_user_state(context)
        return

    processed_files_count = 0
    for file_path in files_to_process:
        try:
            current_file_links = []
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    link = line.strip()
                    if link and not link.startswith("#"): 
                        current_file_links.append(link)
                        all_links_in_archive.append(link)
            files_data[file_path] = current_file_links
            
            processed_files_count += 1
            progress = int((processed_files_count / total_files) * 30)
            await progress_message.edit_text(f"Собираю ссылки: {create_progress_bar(progress)}")
            await asyncio.sleep(0.1)

        except Exception as e:
            await update.message.reply_text(f"Ошибка при чтении файла '{file_path.name}': {e}")
            files_data.pop(file_path, None)

    files_to_process_for_cleaning = list(files_data.keys())

    all_unique_links_global = set(all_links_in_archive)
    global_duplicate_links_master_set = set()
    for link in all_links_in_archive:
        if all_links_in_archive.count(link) > 1:
            global_duplicate_links_master_set.add(link)

    saved_unique_links_master = set() 
    
    files_cleaned_summary = {} 
    
    files_to_process_for_cleaning.sort(key=lambda f: f.stat().st_mtime)

    for file_index, file_path in enumerate(files_to_process_for_cleaning):
        try:
            current_file_links = files_data.get(file_path, [])
            initial_links_count = len(current_file_links)
            links_to_keep_in_this_file = []
            removed_count = 0
            
            seen_in_this_file_temp = set()

            for link in current_file_links:
                is_global_duplicate = link in global_duplicate_links_master_set
                is_already_saved_globally = link in saved_unique_links_master
                is_duplicate_in_this_file = link in seen_in_this_file_temp

                if is_global_duplicate:
                    if not is_already_saved_globally:
                        links_to_keep_in_this_file.append(link)
                        saved_unique_links_master.add(link)
                        seen_in_this_file_temp.add(link)
                    else:
                        removed_count += 1
                        deleted_links_report.append((link, file_path.name, "Глобальный дубликат"))
                else: 
                    if not is_duplicate_in_this_file: 
                        links_to_keep_in_this_file.append(link)
                        seen_in_this_file_temp.add(link)
                    else:
                        removed_count += 1
                        deleted_links_report.append((link, file_path.name, "Дубликат в этом файле"))

            if not links_to_keep_in_this_file and initial_links_count > 0:
                os.remove(file_path)
                status = "Удален (пустой после очистки)"
                removed_count = initial_links_count
                files_removed_report.append((file_path.name, "Файл стал пустым после удаления дубликатов"))
                files_data.pop(file_path, None)
            elif removed_count > 0:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(links_to_keep_in_this_file))
                files_data[file_path] = links_to_keep_in_this_file
                status = "Очищен"
            else:
                status = "Не требуется"

            files_cleaned_summary[file_path.name] = (initial_links_count, removed_count, status)
            
            progress = int(30 + (file_index / len(files_to_process_for_cleaning)) * 70) if files_to_process_for_cleaning else 100
            await progress_message.edit_text(f"Очищаю файлы: {create_progress_bar(progress)}")
            await asyncio.sleep(0.1)

        except Exception as e:
            await update.message.reply_text(f"Ошибка при очистке файла '{file_path.name}': {e}")
            files_cleaned_summary[file_path.name] = (len(files_data.get(file_path, [])), 0, f"Ошибка: {e}")

    folder_link_counts = {}
    total_archive_links = 0

    for file_path, links in files_data.items():
        current_file_link_count = len(links)
        total_archive_links += current_file_link_count

        relative_path = file_path.relative_to(ARCHIVE_DIR)
        
        if len(relative_path.parts) > 1:
            top_level_folder_name = relative_path.parts[0]
            if top_level_folder_name.lower() != 'не':
                folder_link_counts[top_level_folder_name] = folder_link_counts.get(top_level_folder_name, 0) + current_file_link_count

    report_message = "Отчет по сравнению и очистке архивов:\n\n"
    
    report_message += "Количество чатов в каждой папке архива:\n"
    if folder_link_counts:
        for folder, count in sorted(folder_link_counts.items()):
            report_message += f"  - Папка '{folder}': {count} чатов\n"
    else:
        report_message += "  Не найдено папок с чатами в архиве для отображения (или все исключены).\n"
    report_message += f"Всего чатов в архиве: {total_archive_links}\n\n"

    if global_duplicate_links_master_set:
        report_message += f"Найдено {len(global_duplicate_links_master_set)} уникальных дублирующихся ссылок по всем файлам.\n"
        report_message += "Эти ссылки были удалены из файлов (оставлен только один экземпляр).\n\n"
    else:
        report_message += "Глобальных дубликатов не найдено.\n\n"

    report_message += "Сводка по файлам:\n"
    if not files_cleaned_summary:
        report_message += "Нет подходящих файлов для обработки.\n"
    else:
        for file_name, (initial, removed, status) in files_cleaned_summary.items():
            report_message += f"  - {file_name}: Изначально: {initial}, Удалено: {removed}, Статус: {status}\n"

    if deleted_links_report:
        report_message += "\n--- Подробный отчет об удаленных ссылках ---\n"
        for link, file_name, reason in deleted_links_report:
            report_message += f"  - Ссылка: {link}\n    Из файла: {file_name}\n    Причина: {reason}\n"
    else:
        report_message += "\n--- Отчет об удаленных ссылках ---\n"
        report_message += "  Ссылки не были удалены.\n"

    if files_removed_report:
        report_message += "\n--- Подробный отчет об удаленных файлах ---\n"
        for file_name, reason in files_removed_report:
            report_message += f"  - Файл: {file_name}\n    Причина: {reason}\n"
    else:
        report_message += "\n--- Отчет об удаленных файлах ---\n"
        report_message += "  Файлы не были удалены.\n"


    await progress_message.edit_text("Готово! Процесс завершен.")
    
    max_message_length = 4096
    for i in range(0, len(report_message), max_message_length):
        await update.message.reply_text(report_message[i:i + max_message_length])

    await update.message.reply_text(
        "Вы вернулись в главное меню. Выберите режим работы:",
        reply_markup=main_menu_keyboard()
    )
    clear_user_state(context)


async def collect_links_from_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ищет и сохраняет ссылки из сообщения, если все условия выполнены."""
    if context.user_data.get("mode_selected") != "manual": return
    if not update.message.text and not update.message.caption: return
    if not update.message.entities and not update.message.caption_entities: return
    
    if not context.user_data.get("current_tag"):
        await update.message.reply_text("Сначала установите тег.")
        return

    text = update.message.text or update.message.caption
    entities = update.message.entities or update.message.caption_entities
    
    public_min_members = context.user_data.get("public_min_members", load_min_members()["public_min_members"])
    private_min_members = context.user_data.get("private_min_members", load_min_members()["private_min_members"])

    user_links = context.user_data.setdefault("user_links", [])
    added_count = 0
    
    for entity in entities:
        if entity.type not in (MessageEntity.URL, MessageEntity.TEXT_LINK): continue
        url = entity.url or text[entity.offset:entity.offset + entity.length]

        is_private_link = url.startswith("https://t.me/+")
        current_limit = private_min_members if is_private_link else public_min_members

        line_text = ""
        lines = text.split('\n')
        current_offset = 0
        for line in lines:
            line_start = current_offset
            line_end = current_offset + len(line)
            if (line_start <= entity.offset < line_end) or \
               (line_start < entity.offset + entity.length <= line_end) or \
               (entity.offset <= line_start and entity.offset + entity.length >= line_end):
                line_text = line
                break
            current_offset += len(line) + 1

        if not line_text:
            continue

        parsed_members = parse_member_count(line_text)

        if parsed_members < current_limit:
            continue
        
        if url not in user_links:
            user_links.append(url)
            added_count += 1
            
    if added_count > 0:
        await update.message.reply_text(f"➕ Добавлено {added_count} новых ссылок. Всего: {len(user_links)}.")
    else:
        await update.message.reply_text(f"❌ Из этого сообщения не добавлено новых ссылок (всего: {len(user_links)}). Проверьте лимиты или формат данных.")


if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))

    app.add_handler(MessageHandler(filters.Regex("^Назад$"), go_back_to_main_menu))
    app.add_handler(MessageHandler(filters.Regex("^(Ручной режим|Авто режим|Архив чатов|Шаблоны)$"), handle_menu_choice))
    app.add_handler(MessageHandler(
        filters.Regex("^(Установить тег|Узнать тег|Установить лимит|Узнать лимит|✅ Готово \\(Получить чаты\\))$"),
        handle_manual_mode_buttons
    ))
    # Обработчик кнопок меню шаблонов и редактора
    app.add_handler(MessageHandler(filters.Regex("^(Редактор|Просмотр)$"), handle_templates_menu_buttons))
    app.add_handler(MessageHandler(filters.Regex("^(Создать шаблон|Редактировать шаблон|Удалить шаблон|Назад)$"), handle_message))
    app.add_handler(MessageHandler(filters.Regex("^Сравнить ссылки$"), handle_message))
    
    app.add_handler(CallbackQueryHandler(handle_archive_callback, pattern=r"^archive_"))
    
    app.add_handler(CallbackQueryHandler(move_files_to_final_folder, pattern=r"^move_to_folder$"))
    
    # Обработчик инлайн-кнопок шаблонов
    app.add_handler(CallbackQueryHandler(handle_template_callback, pattern=r"^show_template_"))
    app.add_handler(CallbackQueryHandler(handle_template_callback, pattern=r"^block_"))
    
    app.add_handler(CallbackQueryHandler(handle_template_callback, pattern=r"^edit_template_"))
    app.add_handler(CallbackQueryHandler(handle_template_callback, pattern=r"^delete_template_"))
    app.add_handler(CallbackQueryHandler(handle_template_callback, pattern=r"^(confirm_delete_template|edit_template_text|edit_template_buttons|back_to_template_editor)$"))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(MessageHandler(filters.Entity(MessageEntity.URL) | filters.Entity(MessageEntity.TEXT_LINK) | filters.PHOTO, collect_links_from_message))

    print("Бот запущен...")
    app.run_polling()